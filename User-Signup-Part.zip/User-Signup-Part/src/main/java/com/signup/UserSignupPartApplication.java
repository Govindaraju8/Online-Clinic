package com.signup;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UserSignupPartApplication {

	public static void main(String[] args) {
		SpringApplication.run(UserSignupPartApplication.class, args);
	}

}
